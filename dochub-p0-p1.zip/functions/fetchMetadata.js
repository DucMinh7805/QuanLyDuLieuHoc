/**
 * functions/fetchMetadata.js
 * ----------------------------------------------------
 * Cloud Function: fetchMetadata
 * Vai trò: Middleware giữa Dashboard và URL bên ngoài.
 *
 * Lý do cần Backend (không gọi trực tiếp từ browser):
 * - Trình duyệt chặn request cross-origin tới domain khác (CORS).
 * - Cloud Function chạy trên server, không bị giới hạn này, nên có thể
 *   tải HTML thô của bất kỳ URL nào rồi parse ra metadata.
 *
 * Input  (HTTPS callable):  { url: "https://example.com/article" }
 * Output:                   { title, description, faviconUrl, siteName }
 */

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { logger } = require('firebase-functions');
const cheerio = require('cheerio');

const FETCH_TIMEOUT_MS = 8000;
const MAX_HTML_BYTES = 2 * 1024 * 1024; // 2MB — đủ cho <head>, tránh tải cả trang nặng

/**
 * Validate URL đầu vào — chỉ chấp nhận http/https, chặn localhost/private IP
 * để tránh bị lợi dụng làm proxy quét mạng nội bộ (SSRF).
 */
function assertSafeUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new HttpsError('invalid-argument', 'URL không hợp lệ.');
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new HttpsError('invalid-argument', 'Chỉ hỗ trợ URL http/https.');
  }

  const hostname = parsed.hostname.toLowerCase();
  const blockedHosts = ['localhost', '127.0.0.1', '0.0.0.0', '::1'];
  const isPrivateIp =
    /^10\./.test(hostname) ||
    /^192\.168\./.test(hostname) ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(hostname);

  if (blockedHosts.includes(hostname) || isPrivateIp) {
    throw new HttpsError('invalid-argument', 'URL nội bộ không được phép.');
  }

  return parsed;
}

/**
 * Fetch HTML với timeout, giới hạn kích thước, và header User-Agent
 * (nhiều site trả về trang rỗng/chặn nếu thiếu User-Agent giống browser).
 */
async function fetchHtml(url) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; DocHubBot/1.0; +https://dochub.local)',
        Accept: 'text/html,application/xhtml+xml',
      },
    });

    if (!response.ok) {
      throw new HttpsError(
        'unavailable',
        `Không thể tải URL (HTTP ${response.status}).`
      );
    }

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/html')) {
      throw new HttpsError(
        'invalid-argument',
        'URL không trả về nội dung HTML.'
      );
    }

    // Đọc giới hạn số byte để tránh tải trang quá nặng
    const reader = response.body.getReader();
    let received = 0;
    const chunks = [];
    while (received < MAX_HTML_BYTES) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.length;
    }
    reader.cancel().catch(() => {});

    return Buffer.concat(chunks).toString('utf-8');
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Parse metadata từ HTML bằng cheerio.
 * Thứ tự ưu tiên: Open Graph (og:*) > meta thường > fallback.
 */
function parseMetadata(html, baseUrl) {
  const $ = cheerio.load(html);

  const title =
    $('meta[property="og:title"]').attr('content')?.trim() ||
    $('title').first().text()?.trim() ||
    baseUrl.hostname;

  const description =
    $('meta[property="og:description"]').attr('content')?.trim() ||
    $('meta[name="description"]').attr('content')?.trim() ||
    '';

  const siteName =
    $('meta[property="og:site_name"]').attr('content')?.trim() ||
    baseUrl.hostname;

  // Favicon: ưu tiên rel="icon" trong HTML, fallback sang Google Favicon API
  // (Google Favicon API ổn định hơn vì nhiều site không khai báo favicon rõ ràng
  //  hoặc dùng đường dẫn tương đối phức tạp)
  const iconHref =
    $('link[rel="icon"]').attr('href') ||
    $('link[rel="shortcut icon"]').attr('href') ||
    $('link[rel="apple-touch-icon"]').attr('href');

  let faviconUrl;
  if (iconHref) {
    try {
      faviconUrl = new URL(iconHref, baseUrl).toString();
    } catch {
      faviconUrl = null;
    }
  }
  if (!faviconUrl) {
    faviconUrl = `https://www.google.com/s2/favicons?domain=${baseUrl.hostname}&sz=64`;
  }

  return {
    title: title.slice(0, 200),
    description: description.slice(0, 500),
    siteName,
    faviconUrl,
  };
}

/**
 * Cloud Function chính — gọi từ Dashboard qua Firebase SDK:
 *   const fetchMetadata = httpsCallable(functions, 'fetchMetadata');
 *   const { data } = await fetchMetadata({ url });
 */
exports.fetchMetadata = onCall(
  {
    region: 'asia-southeast1',
    timeoutSeconds: 15,
    memory: '256MiB',
    // Cho phép gọi không cần đăng nhập ở P1 (chưa có Auth thật).
    // Khi tích hợp Firebase Auth, đổi sang kiểm tra request.auth.
    cors: true,
  },
  async (request) => {
    const rawUrl = request.data?.url;

    if (!rawUrl || typeof rawUrl !== 'string') {
      throw new HttpsError('invalid-argument', 'Thiếu tham số "url".');
    }

    const parsedUrl = assertSafeUrl(rawUrl);

    try {
      const html = await fetchHtml(parsedUrl.toString());
      const metadata = parseMetadata(html, parsedUrl);

      logger.info('fetchMetadata success', { url: rawUrl });
      return metadata;
    } catch (err) {
      if (err instanceof HttpsError) throw err;

      if (err.name === 'AbortError') {
        throw new HttpsError('deadline-exceeded', 'Trang web phản hồi quá lâu.');
      }

      logger.error('fetchMetadata failed', { url: rawUrl, error: err.message });
      throw new HttpsError('internal', 'Không thể lấy metadata từ URL này.');
    }
  }
);
