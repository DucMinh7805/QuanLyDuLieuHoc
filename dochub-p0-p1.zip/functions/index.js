/**
 * functions/index.js
 * ----------------------------------------------------
 * Entry point — Firebase tự động deploy mọi function được export ở đây.
 * Nếu bạn đã có index.js với function khác, chỉ cần thêm dòng
 * exports tương ứng vào file hiện có, không cần thay thế toàn bộ.
 */

const { fetchMetadata } = require('./fetchMetadata');

exports.fetchMetadata = fetchMetadata;

// P3 sẽ thêm ở đây: exports.createProject = require('./createProject').createProject;
