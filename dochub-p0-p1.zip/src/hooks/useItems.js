/**
 * src/hooks/useItems.js
 * ----------------------------------------------------
 * Custom hook: subscribe real-time vào collection `items`,
 * tự cleanup listener khi component unmount.
 */

import { useState, useEffect } from 'react';
import { subscribeToItems } from '../lib/items';

export function useItems() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = subscribeToItems((data) => {
      setItems(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { items, loading };
}
