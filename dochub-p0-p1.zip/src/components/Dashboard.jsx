/**
 * src/components/Dashboard.jsx
 * ----------------------------------------------------
 * Dashboard chính — nối Firestore thật qua useItems().
 * Khác với bản P0 (dùng MOCK_ITEMS), bản này:
 *   - Đọc items real-time từ Firestore.
 *   - Có QuickCapture để "bắn link" trực tiếp từ Dashboard.
 */

import React, { useState, useMemo } from 'react';
import {
  Inbox, Archive, Zap, Link2, FileText, FolderKanban,
  Search, Tag, X, ExternalLink, Loader2,
} from 'lucide-react';
import { useItems } from '../hooks/useItems';
import QuickCapture from './QuickCapture';

const TYPE_ICON = { link: Link2, note: FileText, project: FolderKanban };
const PRIORITY_DOT = { high: '#E8543E', medium: '#D6A24C', low: '#5C6B73' };

function relativeTime(timestamp) {
  if (!timestamp) return '';
  // Firestore Timestamp có .toDate(); fallback nếu đã là string/Date
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const diff = Date.now() - date.getTime();
  const days = Math.floor(diff / 86400000);
  if (days <= 0) return 'hôm nay';
  if (days === 1) return 'hôm qua';
  if (days < 7) return `${days} ngày trước`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks} tuần trước`;
  return `${Math.floor(days / 30)} tháng trước`;
}

export default function Dashboard() {
  const { items, loading } = useItems();
  const [view, setView] = useState('all'); // all | inbox | archived
  const [categoryFilter, setCategoryFilter] = useState(null);
  const [tagFilter, setTagFilter] = useState(null);
  const [query, setQuery] = useState('');

  const inboxCount = items.filter((i) => i.status === 'inbox').length;

  const categories = useMemo(() => {
    const set = new Set(items.map((i) => i.category).filter(Boolean));
    return Array.from(set);
  }, [items]);

  const tags = useMemo(() => {
    const set = new Set(items.flatMap((i) => i.tags || []));
    return Array.from(set);
  }, [items]);

  const filtered = useMemo(() => {
    return items.filter((i) => {
      if (view === 'inbox' && i.status !== 'inbox') return false;
      if (view === 'archived' && i.status !== 'archived') return false;
      if (view === 'all' && i.status === 'archived') return false;
      if (categoryFilter && i.category !== categoryFilter) return false;
      if (tagFilter && !(i.tags || []).includes(tagFilter)) return false;
      if (query && !i.title?.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
  }, [items, view, categoryFilter, tagFilter, query]);

  const clearFilters = () => { setCategoryFilter(null); setTagFilter(null); setQuery(''); };
  const hasFilters = categoryFilter || tagFilter || query;

  return (
    <div style={styles.app}>
      <div style={styles.scanline} />

      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logo}>
            <span style={styles.logoBracket}>[</span>DOCHUB<span style={styles.logoBracket}>]</span>
          </div>
          <span style={styles.headerSubtitle}>command center · v0.2 · P1</span>
        </div>
        <div style={styles.searchBox}>
          <Search size={14} color="#5C6B73" />
          <input
            style={styles.searchInput}
            placeholder="tìm theo tiêu đề..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </header>

      <div style={styles.captureBar}>
        <QuickCapture />
      </div>

      <div style={styles.body}>
        <aside style={styles.sidebar}>
          <nav style={styles.navGroup}>
            <NavItem icon={Zap} label="Tất cả" active={view === 'all'} onClick={() => setView('all')} />
            <NavItem
              icon={Inbox} label="Inbox" active={view === 'inbox'}
              onClick={() => setView('inbox')} badge={inboxCount > 0 ? inboxCount : null}
            />
            <NavItem icon={Archive} label="Archive" active={view === 'archived'} onClick={() => setView('archived')} />
          </nav>

          <div style={styles.sidebarSection}>
            <div style={styles.sidebarLabel}>CATEGORY</div>
            {categories.length === 0 && <div style={styles.emptySidebar}>chưa có category</div>}
            {categories.map((c) => (
              <FilterChip key={c} label={c} active={categoryFilter === c}
                onClick={() => setCategoryFilter(categoryFilter === c ? null : c)} />
            ))}
          </div>

          <div style={styles.sidebarSection}>
            <div style={styles.sidebarLabel}>TAGS</div>
            <div style={styles.tagCloud}>
              {tags.map((t) => (
                <button key={t} onClick={() => setTagFilter(tagFilter === t ? null : t)}
                  style={{ ...styles.tagPill, ...(tagFilter === t ? styles.tagPillActive : {}) }}>
                  <Tag size={10} style={{ marginRight: 4 }} />{t}
                </button>
              ))}
            </div>
          </div>
        </aside>

        <main style={styles.main}>
          <div style={styles.listHeader}>
            <span style={styles.listTitle}>
              {view === 'inbox' ? 'INBOX — chưa phân loại' : view === 'archived' ? 'ARCHIVE' : 'TẤT CẢ ITEM'}
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              {hasFilters && <button onClick={clearFilters} style={styles.clearBtn}><X size={12} /> xóa lọc</button>}
              <span style={styles.listCount}>{filtered.length} item</span>
            </div>
          </div>

          {loading ? (
            <div style={styles.emptyState}>
              <Loader2 size={20} color="#5C6B73" className="spin" />
              <p style={styles.emptyText}>Đang tải dữ liệu...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div style={styles.emptyState}>
              <span style={styles.emptyGlyph}>·</span>
              <p style={styles.emptyText}>
                {view === 'inbox'
                  ? 'Inbox sạch. Không có gì cần phân loại hôm nay.'
                  : items.length === 0
                    ? 'Chưa có item nào. Dán một URL ở trên để bắt đầu.'
                    : 'Không có item khớp với bộ lọc hiện tại.'}
              </p>
            </div>
          ) : (
            <ul style={styles.list}>
              {filtered.map((item) => <ItemRow key={item.id} item={item} />)}
            </ul>
          )}
        </main>
      </div>

      <style>{`
        .spin { animation: spin 0.8s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, onClick, badge }) {
  return (
    <button onClick={onClick} style={{ ...styles.navItem, ...(active ? styles.navItemActive : {}) }}>
      <Icon size={15} color={active ? '#E8543E' : '#8A9BA3'} />
      <span style={{ flex: 1, textAlign: 'left' }}>{label}</span>
      {badge != null && <span style={styles.navBadge}>{badge}</span>}
    </button>
  );
}

function FilterChip({ label, active, onClick }) {
  return (
    <button onClick={onClick} style={{ ...styles.filterChip, ...(active ? styles.filterChipActive : {}) }}>
      {label}
    </button>
  );
}

function ItemRow({ item }) {
  const Icon = TYPE_ICON[item.type] || Link2;
  const isInbox = item.status === 'inbox';
  return (
    <li style={{ ...styles.row, ...(isInbox ? styles.rowInbox : {}) }}>
      <div style={styles.rowIconCol}>
        <Icon size={16} color={isInbox ? '#E8543E' : '#5C6B73'} />
      </div>
      <div style={styles.rowMain}>
        <div style={styles.rowTitleLine}>
          <span style={styles.rowTitle}>{item.title}</span>
          {item.url && (
            <a href={item.url} target="_blank" rel="noopener noreferrer" style={{ marginLeft: 6, display: 'flex' }}>
              <ExternalLink size={11} color="#5C6B73" />
            </a>
          )}
        </div>
        <div style={styles.rowMeta}>
          {item.category && <span style={styles.metaCategory}>{item.category}</span>}
          {(item.tags || []).map((t) => <span key={t} style={styles.metaTag}>#{t}</span>)}
          {isInbox && <span style={styles.metaInboxFlag}>● chưa phân loại</span>}
        </div>
      </div>
      <div style={styles.rowRight}>
        <span style={{ ...styles.priorityDot, background: PRIORITY_DOT[item.priority] || '#5C6B73' }} />
        <span style={styles.rowTime}>{relativeTime(item.createdAt)}</span>
      </div>
    </li>
  );
}

const FONT_MONO = "'JetBrains Mono', 'SF Mono', Consolas, monospace";
const FONT_SANS = "'Inter', -apple-system, sans-serif";

const styles = {
  app: { minHeight: '100vh', background: '#13171A', color: '#E4E7E9', fontFamily: FONT_SANS, position: 'relative' },
  scanline: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 2,
    background: 'linear-gradient(90deg, transparent, #E8543E, transparent)', opacity: 0.5,
  },
  header: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '16px 24px', borderBottom: '1px solid #232A2E',
  },
  headerLeft: { display: 'flex', alignItems: 'baseline', gap: 12 },
  logo: { fontFamily: FONT_MONO, fontSize: 18, fontWeight: 700, letterSpacing: 1 },
  logoBracket: { color: '#E8543E' },
  headerSubtitle: { fontFamily: FONT_MONO, fontSize: 11, color: '#5C6B73' },
  searchBox: {
    display: 'flex', alignItems: 'center', gap: 8, background: '#1A1F23',
    border: '1px solid #2B3338', borderRadius: 6, padding: '6px 12px', width: 240,
  },
  searchInput: { background: 'transparent', border: 'none', outline: 'none', color: '#E4E7E9', fontFamily: FONT_MONO, fontSize: 12.5, width: '100%' },
  captureBar: { padding: '18px 24px 4px', borderBottom: '1px solid #1C2225' },
  body: { display: 'flex', minHeight: 'calc(100vh - 140px)' },
  sidebar: { width: 200, borderRight: '1px solid #232A2E', padding: '20px 14px', display: 'flex', flexDirection: 'column', gap: 24 },
  navGroup: { display: 'flex', flexDirection: 'column', gap: 2 },
  navItem: {
    display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', background: 'transparent',
    border: 'none', borderRadius: 5, color: '#8A9BA3', fontSize: 13, fontFamily: FONT_SANS, cursor: 'pointer', textAlign: 'left',
  },
  navItemActive: { background: '#1E2528', color: '#E4E7E9' },
  navBadge: { background: '#E8543E', color: '#13171A', fontSize: 10, fontFamily: FONT_MONO, fontWeight: 700, borderRadius: 9, padding: '1px 7px', minWidth: 16, textAlign: 'center' },
  sidebarSection: { display: 'flex', flexDirection: 'column', gap: 6 },
  sidebarLabel: { fontFamily: FONT_MONO, fontSize: 10.5, color: '#4A5459', letterSpacing: 1, marginBottom: 2 },
  emptySidebar: { fontFamily: FONT_MONO, fontSize: 11, color: '#3E464A', fontStyle: 'italic' },
  filterChip: { display: 'block', width: '100%', textAlign: 'left', background: 'transparent', border: 'none', color: '#8A9BA3', fontSize: 12.5, padding: '5px 10px', borderRadius: 5, cursor: 'pointer' },
  filterChipActive: { background: '#27201D', color: '#E8543E' },
  tagCloud: { display: 'flex', flexWrap: 'wrap', gap: 5 },
  tagPill: { fontFamily: FONT_MONO, fontSize: 10.5, color: '#7A8A92', background: '#1A1F23', border: '1px solid #2B3338', borderRadius: 4, padding: '3px 7px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center' },
  tagPillActive: { borderColor: '#E8543E', color: '#E8543E', background: '#211915' },
  main: { flex: 1, padding: '20px 28px' },
  listHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, paddingBottom: 10, borderBottom: '1px solid #232A2E' },
  listTitle: { fontFamily: FONT_MONO, fontSize: 12, letterSpacing: 1.5, color: '#8A9BA3' },
  listCount: { fontFamily: FONT_MONO, fontSize: 11.5, color: '#4A5459' },
  clearBtn: { display: 'flex', alignItems: 'center', gap: 4, background: 'transparent', border: 'none', color: '#E8543E', fontFamily: FONT_MONO, fontSize: 11, cursor: 'pointer', padding: 0 },
  list: { display: 'flex', flexDirection: 'column', gap: 2, listStyle: 'none', margin: 0, padding: 0 },
  row: { display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', borderRadius: 6, borderLeft: '2px solid transparent' },
  rowInbox: { background: '#1A1715', borderLeft: '2px solid #E8543E' },
  rowIconCol: { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 20 },
  rowMain: { flex: 1, display: 'flex', flexDirection: 'column', gap: 3, minWidth: 0 },
  rowTitleLine: { display: 'flex', alignItems: 'center' },
  rowTitle: { fontSize: 13.5, color: '#E4E7E9', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
  rowMeta: { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  metaCategory: { fontFamily: FONT_MONO, fontSize: 10.5, color: '#6B8A7A', background: '#16201B', padding: '1px 6px', borderRadius: 3 },
  metaTag: { fontFamily: FONT_MONO, fontSize: 10.5, color: '#5C6B73' },
  metaInboxFlag: { fontFamily: FONT_MONO, fontSize: 10.5, color: '#E8543E' },
  rowRight: { display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 },
  priorityDot: { width: 6, height: 6, borderRadius: '50%' },
  rowTime: { fontFamily: FONT_MONO, fontSize: 10.5, color: '#4A5459', width: 64, textAlign: 'right' },
  emptyState: { padding: '60px 0', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 },
  emptyGlyph: { fontSize: 32, color: '#2B3338' },
  emptyText: { fontFamily: FONT_MONO, fontSize: 12.5, color: '#5C6B73' },
};
