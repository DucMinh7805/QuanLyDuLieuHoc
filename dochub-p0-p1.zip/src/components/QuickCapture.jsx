/**
 * src/components/QuickCapture.jsx
 * ----------------------------------------------------
 * Khung nhập URL duy nhất (P1 — Ingestion Layer).
 * Luồng xử lý khi user nhấn "Lưu":
 *   1. Validate URL cơ bản ở client.
 *   2. Kiểm tra trùng lặp trong Firestore (findItemByUrl).
 *      → Nếu đã có: báo cho user, không tạo mới.
 *   3. Gọi Cloud Function fetchMetadata để lấy title/description/favicon.
 *   4. Lưu item mới vào Firestore với status='inbox'.
 */

import React, { useState } from 'react';
import { Zap, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { fetchUrlMetadata } from '../lib/metadata';
import { createItem, findItemByUrl } from '../lib/items';

const STATE = {
  IDLE: 'idle',
  CHECKING: 'checking', // đang kiểm tra trùng lặp
  FETCHING: 'fetching', // đang fetch metadata
  SAVING: 'saving',
  SUCCESS: 'success',
  DUPLICATE: 'duplicate',
  ERROR: 'error',
};

function normalizeUrl(raw) {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  // Tự thêm https:// nếu user quên gõ protocol
  if (!/^https?:\/\//i.test(trimmed)) {
    return `https://${trimmed}`;
  }
  return trimmed;
}

export default function QuickCapture() {
  const [rawInput, setRawInput] = useState('');
  const [state, setState] = useState(STATE.IDLE);
  const [errorMessage, setErrorMessage] = useState('');
  const [existingItem, setExistingItem] = useState(null);

  const isBusy = [STATE.CHECKING, STATE.FETCHING, STATE.SAVING].includes(state);

  async function handleSubmit(e) {
    e.preventDefault();
    if (isBusy) return;

    const url = normalizeUrl(rawInput);
    if (!url) {
      setState(STATE.ERROR);
      setErrorMessage('Vui lòng nhập một URL.');
      return;
    }

    try {
      // Bước 1: chống trùng lặp
      setState(STATE.CHECKING);
      const existing = await findItemByUrl(url);
      if (existing) {
        setExistingItem(existing);
        setState(STATE.DUPLICATE);
        return;
      }

      // Bước 2: fetch metadata qua Cloud Function
      setState(STATE.FETCHING);
      const metadata = await fetchUrlMetadata(url);

      // Bước 3: lưu vào Firestore với status='inbox'
      setState(STATE.SAVING);
      await createItem({
        title: metadata.title,
        url,
        description: metadata.description,
        faviconUrl: metadata.faviconUrl,
        type: 'link',
      });

      setState(STATE.SUCCESS);
      setRawInput('');
      setTimeout(() => setState(STATE.IDLE), 2000);
    } catch (err) {
      setState(STATE.ERROR);
      setErrorMessage(err.message || 'Có lỗi xảy ra, thử lại sau.');
    }
  }

  function reset() {
    setState(STATE.IDLE);
    setErrorMessage('');
    setExistingItem(null);
  }

  const statusLabel = {
    [STATE.CHECKING]: 'Đang kiểm tra trùng lặp...',
    [STATE.FETCHING]: 'Đang lấy thông tin trang...',
    [STATE.SAVING]: 'Đang lưu vào Inbox...',
  }[state];

  return (
    <div style={styles.wrap}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.inputBox}>
          <Zap size={15} color="#E8543E" />
          <input
            style={styles.input}
            placeholder="Dán URL vào đây và nhấn Enter..."
            value={rawInput}
            onChange={(e) => {
              setRawInput(e.target.value);
              if (state !== STATE.IDLE) reset();
            }}
            disabled={isBusy}
          />
        </div>
        <button type="submit" style={styles.submitBtn} disabled={isBusy || !rawInput.trim()}>
          {isBusy ? <Loader2 size={14} className="spin" /> : 'Lưu'}
        </button>
      </form>

      {isBusy && (
        <div style={styles.statusLine}>
          <Loader2 size={12} color="#8A9BA3" className="spin" />
          <span style={styles.statusText}>{statusLabel}</span>
        </div>
      )}

      {state === STATE.SUCCESS && (
        <div style={{ ...styles.statusLine, color: '#6B8A7A' }}>
          <CheckCircle2 size={13} color="#6B8A7A" />
          <span style={styles.statusText}>Đã lưu vào Inbox.</span>
        </div>
      )}

      {state === STATE.DUPLICATE && existingItem && (
        <div style={{ ...styles.statusLine, color: '#D6A24C' }}>
          <AlertCircle size={13} color="#D6A24C" />
          <span style={styles.statusText}>
            Link này đã có trong hệ thống: "{existingItem.title}"
          </span>
          <button onClick={reset} style={styles.dismissBtn}>bỏ qua</button>
        </div>
      )}

      {state === STATE.ERROR && (
        <div style={{ ...styles.statusLine, color: '#E8543E' }}>
          <AlertCircle size={13} color="#E8543E" />
          <span style={styles.statusText}>{errorMessage}</span>
          <button onClick={reset} style={styles.dismissBtn}>đóng</button>
        </div>
      )}

      <style>{`
        .spin { animation: spin 0.8s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

const FONT_MONO = "'JetBrains Mono', 'SF Mono', Consolas, monospace";

const styles = {
  wrap: { display: 'flex', flexDirection: 'column', gap: 6 },
  form: { display: 'flex', gap: 8 },
  inputBox: {
    flex: 1, display: 'flex', alignItems: 'center', gap: 10,
    background: '#1A1F23', border: '1px solid #2B3338', borderRadius: 7,
    padding: '10px 14px',
  },
  input: {
    flex: 1, background: 'transparent', border: 'none', outline: 'none',
    color: '#E4E7E9', fontFamily: FONT_MONO, fontSize: 13,
  },
  submitBtn: {
    background: '#E8543E', color: '#13171A', border: 'none', borderRadius: 7,
    padding: '0 20px', fontWeight: 700, fontSize: 13, cursor: 'pointer',
    fontFamily: FONT_MONO, minWidth: 64,
  },
  statusLine: {
    display: 'flex', alignItems: 'center', gap: 6, paddingLeft: 4,
  },
  statusText: { fontFamily: FONT_MONO, fontSize: 11.5, color: '#8A9BA3' },
  dismissBtn: {
    marginLeft: 'auto', background: 'transparent', border: 'none',
    color: '#5C6B73', fontFamily: FONT_MONO, fontSize: 11, cursor: 'pointer',
    textDecoration: 'underline',
  },
};
