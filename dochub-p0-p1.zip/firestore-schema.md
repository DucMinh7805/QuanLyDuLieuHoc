# DocHub — Firestore Database Schema (P0)

## 1. Tổng quan collections

```
firestore-root/
├── items/          (collection chính — mọi link/note/project)
├── projects/        (sub-info riêng cho item type='project': notion_url, drive_url)
└── users/          (P0 dùng 1 user giả định, chuẩn bị cho multi-user về sau)
```

Quyết định thiết kế: dùng **1 collection `items` duy nhất** (không tách `links`, `notes`, `projects` riêng) vì:
- Dashboard cần query/filter chung (theo Tag, Category, Status) trên toàn bộ data — tách collection sẽ phải query nhiều lần rồi merge ở client, tốn round-trip.
- Field `type` phân biệt loại item, đủ để filter khi cần.
- Khi data lớn (Tiered Storage ở P3), việc archive/move cũng đơn giản hơn với 1 collection.

---

## 2. Collection: `items`

Đây là collection trung tâm — đại diện cho mọi đối tượng được "bắn" vào DocHub (link, note, project).

| Field             | Type        | Bắt buộc | Mô tả |
|-------------------|-------------|----------|-------|
| `id`              | string (doc id, auto) | ✓ | Firestore tự sinh |
| `title`           | string      | ✓ | Tiêu đề (fetch tự động hoặc nhập tay) |
| `url`             | string      | — | URL nguồn (null nếu là note thuần) |
| `description`     | string      | — | Mô tả ngắn (fetch từ meta tag hoặc nhập tay) |
| `faviconUrl`      | string      | — | Favicon của domain nguồn |
| `type`            | enum string | ✓ | `'link' \| 'note' \| 'project'` |
| `status`          | enum string | ✓ | `'inbox' \| 'archived' \| 'active'` — mặc định `'inbox'` |
| `category`        | string      | — | Gán khi user xử lý Inbox (vd: "Y khoa", "Tài chính"...) |
| `tags`            | array<string> | — | Mặc định `[]` |
| `priority`        | enum string | — | `'low' \| 'medium' \| 'high'`, mặc định `'medium'` |
| `sourceId`        | string      | — | ID tham chiếu nguồn gốc (vd: ID bookmarklet session, để debug) |
| `notionUrl`       | string      | — | Chỉ có nếu type='project' — set bởi Cloud Function (P3) |
| `driveUrl`        | string      | — | Chỉ có nếu type='project' — set bởi Cloud Function (P3) |
| `createdAt`       | timestamp   | ✓ | `serverTimestamp()` khi tạo |
| `updatedAt`       | timestamp   | ✓ | Cập nhật mỗi lần sửa |
| `lastAccessedDate`| timestamp   | — | Cập nhật khi user mở lại item — dùng cho Tiered Storage (P3) |
| `isArchived`      | boolean     | ✓ | Mặc định `false`. Khi `true` → ứng viên chuyển "Cold storage" |

### Index cần tạo (Firestore composite indexes)
Để dashboard filter nhanh, cần các composite index sau (Firestore sẽ tự gợi ý khi bạn chạy query lần đầu, nhưng nên khai báo trước trong `firestore.indexes.json`):

1. `status` (==) + `createdAt` (desc) — cho view Inbox
2. `category` (==) + `createdAt` (desc) — cho filter theo Category
3. `tags` (array-contains) + `createdAt` (desc) — cho filter theo Tag
4. `isArchived` (==) + `lastAccessedDate` (asc) — cho job tìm item cần archive (P3)

### Chống trùng lặp URL
Trước khi `addDoc`, luôn query:
```js
where('url', '==', newUrl)
```
Nếu có kết quả → không tạo mới, show toast "Link đã tồn tại trong hệ thống" + link tới item cũ.

---

## 3. Collection: `users` (chuẩn bị, P0 chưa dùng thật)

| Field        | Type   | Mô tả |
|--------------|--------|-------|
| `uid`        | string | Firebase Auth UID |
| `displayName`| string | |
| `email`      | string | |
| `createdAt`  | timestamp | |

P0: hard-code 1 user object ở client, không query collection này. Khi tích hợp Firebase Auth thật (sau P4), mọi document trong `items` sẽ cần thêm field `ownerId` để scope theo user.

---

## 4. Security Rules (định hướng — áp dụng từ khi có Auth thật)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /items/{itemId} {
      allow read, write: if request.auth != null
                          && request.auth.uid == resource.data.ownerId;
      allow create: if request.auth != null
                     && request.auth.uid == request.resource.data.ownerId;
    }
  }
}
```
P0 chưa có Auth → dùng test mode rules tạm thời (`allow read, write: if true;`) **chỉ cho môi trường dev**, không deploy production với rule này.

---

## 5. Mapping với roadmap

| Field/Cơ chế          | Dùng ở Priority |
|-----------------------|-----------------|
| `title`, `url`, `status='inbox'` | P1 (Quick Capture) |
| `sourceId`, bookmarklet ghi thẳng vào `items` | P2 |
| `notionUrl`, `driveUrl` | P3 (Cloud Functions) |
| `category`, `tags`, quy trình inbox→archive | P4 (Inbox Zero) |
| `isArchived`, `lastAccessedDate` | P3 (Tiered Storage) |

---

## 6. Mock data mẫu (dùng cho Dashboard P0 trước khi có Cloud Functions thật)

```json
[
  {
    "id": "mock1",
    "title": "UWorld Step 1 - Cardiology QBank",
    "url": "https://uworld.com/cardio",
    "type": "link",
    "status": "active",
    "category": "Y khoa",
    "tags": ["uworld", "cardio", "step1"],
    "priority": "high",
    "createdAt": "2026-06-20T08:00:00Z"
  },
  {
    "id": "mock2",
    "title": "Đồ án tốt nghiệp - Outline",
    "type": "project",
    "status": "active",
    "category": "Học tập",
    "tags": ["thesis"],
    "priority": "high",
    "notionUrl": "https://notion.so/mock-page",
    "driveUrl": "https://drive.google.com/mock-folder",
    "createdAt": "2026-06-18T10:00:00Z"
  },
  {
    "id": "mock3",
    "title": "Bài báo NEJM về Sepsis 2026",
    "url": "https://nejm.org/sepsis-2026",
    "type": "link",
    "status": "inbox",
    "tags": [],
    "createdAt": "2026-06-23T14:00:00Z"
  }
]
```
