# DocHub — Command Center cá nhân

Trạm chỉ huy cá nhân kết nối Google Drive & Notion. Đây là bản P0 (Dashboard + Schema) và P1 (Quick Capture + Fetch Metadata).

## Cấu trúc project

```
dochub/
├── src/                      → Frontend (React + Vite)
│   ├── lib/
│   │   ├── firebase.js       → Khởi tạo Firebase App/Firestore/Functions
│   │   ├── items.js          → CRUD collection `items` + chống trùng URL
│   │   └── metadata.js       → Gọi Cloud Function fetchMetadata
│   ├── hooks/
│   │   └── useItems.js       → Hook subscribe real-time vào Firestore
│   ├── components/
│   │   ├── Dashboard.jsx     → Màn hình chính
│   │   └── QuickCapture.jsx  → Khung nhập URL
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── functions/                → Backend (Cloud Functions)
│   ├── index.js              → Entry point, export các functions
│   ├── fetchMetadata.js      → Function fetch Title/Description/Favicon
│   └── package.json
├── firestore.rules           → Security rules (chế độ dev)
├── firestore.indexes.json    → Composite indexes
├── firebase.json             → Cấu hình Firebase CLI
├── firestore-schema.md       → Tài liệu thiết kế schema chi tiết
└── package.json
```

## Bước 1 — Điền Firebase config

Mở `src/lib/firebase.js`, thay các giá trị `YOUR_...` bằng config thật,
lấy tại **Firebase Console → Project Settings → General → Your apps → SDK setup and configuration**.

```js
const firebaseConfig = {
  apiKey: 'AIzaSy...',
  authDomain: 'ten-project.firebaseapp.com',
  projectId: 'ten-project',
  storageBucket: 'ten-project.appspot.com',
  messagingSenderId: '...',
  appId: '...',
};
```

## Bước 2 — Cài dependencies

```bash
# Frontend
npm install

# Backend (Cloud Functions)
cd functions
npm install
cd ..
```

## Bước 3 — Deploy Cloud Functions trước

Function `fetchMetadata` cần chạy thật trên Firebase trước khi Dashboard gọi được.

```bash
# Đăng nhập (nếu chưa)
firebase login

# Chọn đúng project (nếu máy bạn có nhiều project Firebase)
firebase use --add

# Deploy chỉ functions + firestore rules/indexes
firebase deploy --only functions,firestore
```

Sau khi chạy xong, kiểm tra trên **Firebase Console → Functions** thấy `fetchMetadata`
ở region `asia-southeast1` là thành công.

> Nếu deploy lỗi do thiếu billing: Cloud Functions thế hệ 2 (mà code này dùng,
> qua `firebase-functions/v2/https`) yêu cầu project ở **Blaze plan** (pay-as-you-go).
> Free tier (Spark) không deploy được Functions Gen 2. Mức dùng cho project cá nhân nhỏ
> như DocHub thường nằm trong giới hạn miễn phí của Blaze (2 triệu lượt gọi/tháng).

## Bước 4 — Chạy frontend local để test

```bash
npm run dev
```

Mở `http://localhost:5173`, dán một URL vào khung Quick Capture, nhấn **Lưu**.
Luồng chạy: kiểm tra trùng lặp → gọi Cloud Function lấy metadata → lưu Firestore →
item xuất hiện ngay trong Inbox (real-time, không cần refresh).

## Bước 5 — Build & đẩy GitHub

```bash
npm run build      # tạo thư mục dist/
git init
git add .
git commit -m "DocHub P0+P1: schema, dashboard, quick capture"
git remote add origin <your-repo-url>
git push -u origin main
```

`.gitignore` đã loại trừ `node_modules/`, `dist/`, và mọi file `.env` —
an toàn để public repo (vì `apiKey` Firebase web không phải secret nhạy cảm,
được Google bảo vệ qua Security Rules + domain restriction, không qua việc giấu key).

## Bước 6 — Đóng gói Android bằng Capacitor (để lên CH Play)

Sau khi web app chạy ổn:

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init DocHub com.tenban.dochub --web-dir=dist
npm run build
npx cap add android
npx cap sync
npx cap open android
```

Lệnh cuối mở Android Studio — từ đó build APK/AAB và nộp lên Play Console
theo quy trình chuẩn của Google (cần tài khoản Play Console, phí đăng ký một lần).

## Việc cần làm tiếp (sau P1)

| Priority | Việc |
|---|---|
| P2 | Bookmarklet — đoạn JS nhỏ để lưu link không cần mở app |
| P3 | Cloud Function tạo Notion Page + Drive Folder cho "New Project" |
| P4 | UI gắn Category/Tag để chuyển item từ Inbox → Archive/Projects |
| Bảo mật | Thêm Firebase Auth, cập nhật `firestore.rules` để scope theo `ownerId` |

Xem chi tiết schema và lý do thiết kế tại [`firestore-schema.md`](./firestore-schema.md).
